const apiUrl = 'http://localhost:5000/api';  // Update this if backend is deployed

// Example of sending a login request
async function loginUser(username, password) {
  const res = await fetch(`${apiUrl}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  });
  const data = await res.json();
  if (data.token) {
    localStorage.setItem('token', data.token);  // Store token in browser for session
    window.location.href = 'dashboard.html';  // Redirect to dashboard
  } else {
    alert('Login failed');
  }
}