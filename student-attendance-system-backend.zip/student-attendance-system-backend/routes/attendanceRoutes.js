const express = require('express');
const Attendance = require('../models/Attendance');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Add attendance record (requires auth)
router.post('/add', authMiddleware, async (req, res) => {
  const { studentName, course, status } = req.body;

  try {
    const attendance = new Attendance({ studentName, course, status, createdBy: req.user.id });
    await attendance.save();
    res.status(201).json(attendance);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all attendance records (requires auth)
router.get('/', authMiddleware, async (req, res) => {
  try {
    const records = await Attendance.find({ createdBy: req.user.id });
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Search attendance records by student name or date (requires auth)
router.get('/search', authMiddleware, async (req, res) => {
  const { studentName, startDate, endDate } = req.query;

  try {
    let query = { createdBy: req.user.id };

    if (studentName) {
      query.studentName = { $regex: studentName, $options: 'i' }; // Case-insensitive search
    }

    if (startDate && endDate) {
      query.date = { $gte: new Date(startDate), $lte: new Date(endDate) };
    }

    const records = await Attendance.find(query);
    res.json(records);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update attendance record (requires auth)
router.put('/:id', authMiddleware, async (req, res) => {
  const { status } = req.body;

  try {
    const attendance = await Attendance.findOneAndUpdate(
      { _id: req.params.id, createdBy: req.user.id },
      { status },
      { new: true }
    );

    if (!attendance) return res.status(404).json({ msg: 'Attendance not found' });

    res.json(attendance);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete attendance record (requires auth)
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const attendance = await Attendance.findOneAndDelete({ _id: req.params.id, createdBy: req.user.id });

    if (!attendance) return res.status(404).json({ msg: 'Attendance not found' });

    res.json({ msg: 'Attendance deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;