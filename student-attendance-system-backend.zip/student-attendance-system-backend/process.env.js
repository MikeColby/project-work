const mongoose = require('mongoose');

const dbUrl = process.env.DATABASE_URL; // Accessing the environment variable

mongoose.connect(dbUrl, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Database connected!'))
    .catch(err => console.error('Database connection error:', err));